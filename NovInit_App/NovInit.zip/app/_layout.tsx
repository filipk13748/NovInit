import { View, Text } from 'react-native';
import React from 'react';
import { Tabs } from 'expo-router';
import TabBar from '@/components/TabBar';

export default function _layout() {
  return <Tabs tabBar={(props) => <TabBar {...props} />}>
    <Tabs.Screen name='learn' options={{ title: 'Learn', headerShown: false }} />
    <Tabs.Screen name='index' options={{ title: 'Translator', headerShown: false }} />
    <Tabs.Screen name='settings' options={{ title: 'Settings', headerShown: false }} />
  </Tabs>
}
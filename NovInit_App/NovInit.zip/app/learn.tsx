import React from 'react';
import { FlatList, View, Text, Image, StyleSheet } from 'react-native';
import { useFonts } from 'expo-font';

// TypeScript interface for images object with string keys (A to Z)
const signsAlphabet: { [key: string]: any } = {
  A: require('../assets/images/alphabet/A.png'),
  B: require('../assets/images/alphabet/B.png'),
  C: require('../assets/images/alphabet/C.png'),
  D: require('../assets/images/alphabet/D.png'),
  E: require('../assets/images/alphabet/E.png'),
  F: require('../assets/images/alphabet/F.png'),
  G: require('../assets/images/alphabet/G.png'),
  H: require('../assets/images/alphabet/H.png'),
  I: require('../assets/images/alphabet/I.png'),
  J: require('../assets/images/alphabet/J.png'),
  K: require('../assets/images/alphabet/K.png'),
  L: require('../assets/images/alphabet/L.png'),
  M: require('../assets/images/alphabet/M.png'),
  N: require('../assets/images/alphabet/N.png'),
  O: require('../assets/images/alphabet/O.png'),
  P: require('../assets/images/alphabet/P.png'),
  Q: require('../assets/images/alphabet/Q.png'),
  R: require('../assets/images/alphabet/R.png'),
  S: require('../assets/images/alphabet/S.png'),
  T: require('../assets/images/alphabet/T.png'),
  U: require('../assets/images/alphabet/U.png'),
  V: require('../assets/images/alphabet/V.png'),
  W: require('../assets/images/alphabet/W.png'),
  X: require('../assets/images/alphabet/X.png'),
  Y: require('../assets/images/alphabet/Y.png'),
  Z: require('../assets/images/alphabet/Z.png'),
};

const signsEmotions: { [key: string]: any } = {
  Love: require('../assets/images/emotions/Love.png'),
};

export default function App() {
  const [loaded, error] = useFonts({
    'RobotoMono-SemiBold': require('../assets/fonts/Roboto_Mono/static/RobotoMono-SemiBold.ttf'),
    'RobotoMono-Light': require('../assets/fonts/Roboto_Mono/static/RobotoMono-Regular.ttf'),
  });

  if (!loaded) {
    return null;
  }

  // Data arrays for FlatList
  const alphabetData = Object.keys(signsAlphabet).map((key) => ({
    key,
    image: signsAlphabet[key],
  }));
  const emotionsData = Object.keys(signsEmotions).map((key) => ({
    key,
    image: signsEmotions[key],
  }));

  // Render item for FlatList
  const renderAlphabet = ({ item }: { item: { key: string; image: any } }) => (
    <View style={styles.signBox}>
      <Image source={item.image} style={styles.signBoxImage} />
      <View style={styles.signTitleBox}>
        <Text style={styles.signBoxText}>{item.key}</Text>
      </View>
    </View>
  );
    const renderEmotions = ({ item }: { item: { key: string; image: any } }) => (
    <View style={styles.signEmotionBox}>
      <Image source={item.image} style={styles.signBoxImage} />
      <View style={styles.signTitleBox}>
        <Text style={styles.signBoxText}>{item.key}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* FlatList for Alphabet Signs */}
      <Text style={styles.groupTitle}>
        Alphabet
      </Text>
      <FlatList
        data={alphabetData}
        horizontal
        showsHorizontalScrollIndicator={false}
        renderItem={renderAlphabet}
        keyExtractor={(item) => item.key}
        contentContainerStyle={styles.horizontalFlatList}
      />
      <Text style={styles.groupTitle}>
        Emotions
      </Text>
      {/* FlatList for Emotion Signs */}
      <FlatList
        data={emotionsData}
        horizontal
        showsHorizontalScrollIndicator={false}
        renderItem={renderEmotions}
        keyExtractor={(item) => item.key}
        contentContainerStyle={styles.horizontalFlatList}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#151515',
    padding: 7,
  },
  horizontalFlatList: {
    marginVertical: 8,
  },
  groupTitle: {
    fontSize: 24,
    color: 'white',
    marginVertical: 5,
    textAlign: 'center',
    fontFamily: 'RobotoMono-Light',
  },
  signBox: {
    width: 110,
    height: 210,
    marginHorizontal: 3.5,
    backgroundColor: '#ffe9f0',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 24,
  },
  signEmotionBox: {
    width: 110,
    height: 210,
    marginHorizontal: 3.5,
    backgroundColor: '#ffe9f0',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 24,


  },
  signTitleBox: {
    width: '87%',
    height: 32,
    position: 'absolute',
    bottom: '3.5%',
    borderBottomEndRadius: 18,
    borderBottomLeftRadius: 18,
    borderTopLeftRadius: 7,
    borderTopEndRadius: 7,
    backgroundColor: '#5f5f5f',
    alignItems: 'center',
  },
  signBoxImage: {
    width: 160,
    height: 160,
    bottom: 13,
  },
  signBoxText: {
    color: '#fff',
    fontSize: 17,
    fontFamily: 'RobotoMono-SemiBold',
    position: 'absolute',
    bottom: '16%',
  },
});
